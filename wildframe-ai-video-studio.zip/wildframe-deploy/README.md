# Wildframe AI Video Studio

A mobile-friendly AI video generation website with a serverless backend. It uses Replicate's official `prunaai/p-video` model for text-to-video and optional image-to-video.

## Important before publishing

- The site will not generate videos until you add your own `REPLICATE_API_TOKEN` in the host's environment settings.
- Video inference is billed by the provider and is not guaranteed to be free. Check current pricing and usage limits on the model page before generating.
- Do not place API tokens in `index.html`, client-side JavaScript, screenshots, or public repositories.
- This starter does not include user accounts, persistent video storage, abuse prevention beyond basic request validation, or a database. Add these before offering it to the public at scale.

## Easiest deployment path (Vercel)

1. Download and unzip this project.
2. Create an account at https://vercel.com/ and a private GitHub repository at https://github.com/.
3. Upload the contents of this folder to the repository (the `index.html` file should be at the repository root).
4. In Vercel, import that repository and deploy it.
5. In the Vercel project settings, open **Environment Variables** and add:
   - Name: `REPLICATE_API_TOKEN`
   - Value: your token from https://replicate.com/account/api-tokens
   - Environment: Production (and Preview if you want)
6. Redeploy after adding the variable.
7. Open the Vercel deployment URL and test with a short prompt. Check the model's current cost before generating.
8. To appear in Google Search, add the deployed URL to Google Search Console: https://search.google.com/search-console/about

## What is implemented

- Text-to-video prompt generation.
- Optional reference image upload (resized in the browser before sending).
- 5, 8, and 10 second clip choices.
- Landscape, portrait, and square aspect ratios.
- Video generation status polling and playable output.
- API token stored server-side as an environment variable.

## Local preview

Requires Node.js. Run `npm install`, then `npm run dev`. Set `REPLICATE_API_TOKEN` in your local environment first, or use Vercel's local environment setup. Never commit `.env` files.

## Model and API references

- Model schema: https://replicate.com/prunaai/p-video/api/schema
- Replicate API docs: https://replicate.com/docs
