export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST.' });
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return res.status(503).json({ error: 'Video engine is not configured yet. Add REPLICATE_API_TOKEN in your hosting environment settings.' });
  try {
    const body = req.body || {};
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt || prompt.length > 1800) return res.status(400).json({ error: 'Enter a prompt between 1 and 1800 characters.' });
    const duration = Number(body.duration || 5);
    if (![5, 8, 10].includes(duration)) return res.status(400).json({ error: 'Choose a 5, 8, or 10 second clip.' });
    const aspect = ['16:9', '9:16', '1:1'].includes(body.aspect_ratio) ? body.aspect_ratio : '16:9';
    const input = {
      prompt,
      duration,
      aspect_ratio: aspect,
      resolution: '720p',
      fps: 24,
      draft: false,
      prompt_upsampling: true,
      save_audio: body.save_audio !== false
    };
    if (typeof body.image === 'string' && body.image.startsWith('data:image/') && body.image.length < 270000) input.image = body.image;
    const upstream = await fetch('https://api.replicate.com/v1/models/prunaai/p-video/predictions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Prefer: 'wait=1' },
      body: JSON.stringify({ input })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: data.detail || data.title || data.error || 'The video provider rejected the request.' });
    return res.status(200).json(data);
  } catch (error) {
    return res.status(500).json({ error: 'Server error while starting video generation.' });
  }
}
