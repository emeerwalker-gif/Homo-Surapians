export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET.' });
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return res.status(503).json({ error: 'Video engine is not configured yet.' });
  const id = typeof req.query.id === 'string' ? req.query.id : '';
  if (!/^[a-zA-Z0-9_-]{5,100}$/.test(id)) return res.status(400).json({ error: 'Invalid prediction id.' });
  try {
    const upstream = await fetch(`https://api.replicate.com/v1/predictions/${encodeURIComponent(id)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status >= 500 ? 502 : upstream.status).json({ error: data.detail || data.title || 'Could not check prediction.' });
    return res.status(200).json(data);
  } catch {
    return res.status(500).json({ error: 'Server error while checking video status.' });
  }
}
